package JavaOO;

public interface Interface {

}
