package JavaOO;

public class Produto {
    private double preco;
    public String nome;

    public Produto(String nome, double preco) {
        this.setNome(nome);
        this.setPreco(preco);
    }

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	public String getNome() {
		// TODO Auto-generated method stub
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	
	}
	
			}

  

