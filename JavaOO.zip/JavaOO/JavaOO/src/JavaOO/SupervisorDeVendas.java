package JavaOO;

public class SupervisorDeVendas extends Vendedor {

    public SupervisorDeVendas(String nome, double salario) {
        super(nome, salario);
    }

    @Override
    public void vender(Produto produto, Cliente cliente) {
        System.out.println(getNome() + " (Supervisor) vendeu " + produto.getNome() + " para " + cliente.getNome() + " e ofereceu suporte VIP!");
    }

    public void supervisionarVendedor(Vendedor vendedor) {
        System.out.println(getNome() + " est� supervisionando o vendedor " + vendedor.getNome());
    }
}

