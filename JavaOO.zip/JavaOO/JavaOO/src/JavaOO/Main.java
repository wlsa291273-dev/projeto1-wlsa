package JavaOO;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // CLIENTE
        System.out.println("=== Cadastro do Cliente ===");
        System.out.print("Nome do cliente: ");
        String nomeCliente = scanner.nextLine();
        System.out.print("Email do cliente: ");
        String emailCliente = scanner.nextLine();
        Cliente cliente = new Cliente(nomeCliente, emailCliente);

        // PRODUTO
        System.out.println("\n=== Cadastro do Produto ===");
        System.out.print("Nome do produto: ");
        String nomeProduto = scanner.nextLine();
        System.out.print("Preço do produto: ");
        double precoProduto = scanner.nextDouble();
        scanner.nextLine(); // limpar buffer
        Produto produto = new Produto(nomeProduto, precoProduto);

        // VENDEDOR
        System.out.println("\n=== Cadastro do Vendedor ===");
        System.out.print("Nome do vendedor: ");
        String nomeVendedor = scanner.nextLine();
        System.out.print("Salário do vendedor: ");
        double salarioVendedor = scanner.nextDouble();
        scanner.nextLine(); // limpar buffer
        Vendedor vendedor = new Vendedor(nomeVendedor, salarioVendedor);

        // SUPERVISOR
        System.out.println("\n=== Cadastro do Supervisor ===");
        System.out.print("Nome do supervisor: ");
        String nomeSupervisor = scanner.nextLine();
        System.out.print("Salário do supervisor: ");
        double salarioSupervisor = scanner.nextDouble();
        scanner.nextLine(); // limpar buffer
        SupervisorDeVendas supervisor = new SupervisorDeVendas(nomeSupervisor, salarioSupervisor);

        // SIMULAÇÃO DE VENDA
        System.out.println("\n=== Simulação de Vendas ===");
        vendedor.vender(produto, cliente);
        supervisor.vender(produto, cliente);
        supervisor.supervisionarVendedor(vendedor);

        scanner.close();
    }
}